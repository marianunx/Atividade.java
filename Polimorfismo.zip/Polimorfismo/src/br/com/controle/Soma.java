/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.com.controle;

/**
 *
 * @author maria.ebezerra
 */
public class Soma extends OperacaoMatematica{
    public Double calcular(Double valor1, Double valor2){
        return valor1+valor2;
    }
    
    
    
}
